// v4.3.9
// claude_splash_screen.dart
// lib/ui/splash_screen.dart
// [v4.3.9 Claude 재작성] 버그수정 4건 (아래 참조)
// 앱 스플래시 화면 — 설정에서 선택한 WidgetTheme에 따라 4종 애니메이션 표시
// [v4.3.9 신규]
// - A: FlipSplash    — 플립 시계 스타일, 블루 배경
// - B: CircleSplash  — 영롱한 액체 그라데이션 + 유리 오버레이
// - C: ClassicSplash — 4개 색상 링 독자 회전 + 중앙 카드
// - D: AstronomicalSplash — 성운 배경 + 3개 글로우 링 + 별빛
// 사용: main.dart에서 home: SplashScreen() → 내부에서 CalendarScreen으로 자동 전환
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import 'dart:ui' as ui;
import 'calendar_screen.dart';

// ── ISO 8601 주차 계산 ────────────────────────────────────────────
int _isoWeek(DateTime d) {
  final startOfYear = DateTime(d.year, 1, 1);
  final dayOfYear = d.difference(startOfYear).inDays + 1;
  final weekNum = ((dayOfYear - d.weekday + 10) / 7).floor();
  return weekNum < 1 ? _isoWeek(DateTime(d.year - 1, 12, 31)) : weekNum;
}

// ── 날짜 포맷 헬퍼 ───────────────────────────────────────────────
const _weekdayLabels = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
const _monthLabels = [
  'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN',
  'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'
];
String _weekday(DateTime d) => _weekdayLabels[d.weekday - 1];
String _month(DateTime d) => _monthLabels[d.month - 1];
String _weekStr(DateTime d) => '${_isoWeek(d)}주차';

// ════════════════════════════════════════════════════════════════
// SplashScreen — 진입점
// ════════════════════════════════════════════════════════════════

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen> {
  // 스플래시 표시 시간 (ms)
  static const _splashDuration = Duration(milliseconds: 2200);

  @override
  void initState() {
    super.initState();
    Future.delayed(_splashDuration, _goToCalendar);
  }

  void _goToCalendar() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const CalendarScreen(),
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = ref.watch(settingsProvider).dynamicWidgetTheme;
    return switch (theme) {
      WidgetTheme.flip          => const FlipSplash(),
      WidgetTheme.circle        => const CircleSplash(),
      WidgetTheme.classic       => const ClassicSplash(),
      WidgetTheme.astronomical  => const AstronomicalSplash(),
    };
  }
}

// ════════════════════════════════════════════════════════════════
// A · FlipSplash — 플립 시계 스타일
// ════════════════════════════════════════════════════════════════

class FlipSplash extends StatefulWidget {
  const FlipSplash({super.key});

  @override
  State<FlipSplash> createState() => _FlipSplashState();
}

class _FlipSplashState extends State<FlipSplash>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _flip;

  @override
  void initState() {
    super.initState();
    // [수정1] forward() 단발 → repeat(reverse:true): 2.2초 내내 플립 지속
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
    _flip = CurvedAnimation(parent: _ctrl, curve: Curves.easeInOutBack);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    const bg = Color(0xFF1E88E5);

    return Scaffold(
      backgroundColor: bg,
      body: Stack(children: [
        // 상단 버튼 바
        Positioned(
          top: 56, right: 28,
          child: Row(children: [
            _iconBtn(Icons.add),
            const SizedBox(width: 10),
            _iconBtn(Icons.search),
          ]),
        ),
        // 중앙 날짜
        Center(
          child: AnimatedBuilder(
            animation: _flip,
            builder: (_, __) => Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..setEntry(3, 2, 0.001)
                ..rotateX((_flip.value - 0.5) * 0.4), // ±0.2rad 양방향 플립
              child: _dateColumn(now),
            ),
          ),
        ),
        // 하단 바
        Positioned(
          bottom: 0, left: 0, right: 0,
          child: _bottomBar(),
        ),
      ]),
    );
  }

  Widget _iconBtn(IconData icon) => Container(
    width: 36, height: 36,
    decoration: BoxDecoration(
      color: Colors.white.withValues(alpha: .18),
      borderRadius: BorderRadius.circular(10),
    ),
    child: Icon(icon, color: Colors.white, size: 18),
  );

  Widget _dateColumn(DateTime now) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      // 가로 분할선이 있는 큰 날짜 숫자
      Stack(alignment: Alignment.center, children: [
        Text(
          now.day.toString().padLeft(2, '0'),
          style: const TextStyle(
            fontFamily: 'BebasNeue',
            fontSize: 160,
            color: Colors.white,
            height: .9,
            letterSpacing: -6,
            shadows: [Shadow(blurRadius: 24, color: Color(0x33000000))],
          ),
        ),
        Positioned(
          left: -20, right: -20,
          child: Container(height: 1.5, color: Colors.white.withValues(alpha: .15)),
        ),
      ]),
      const SizedBox(height: 8),
      Text(
        '${_weekday(now)}  ${_month(now)}',
        style: const TextStyle(
          fontFamily: 'CourierPrime',
          fontSize: 20, fontWeight: FontWeight.w700,
          color: Colors.white, letterSpacing: 7,
        ),
      ),
      const SizedBox(height: 6),
      Text(
        _weekStr(now),
        style: TextStyle(
          fontFamily: 'CourierPrime',
          fontSize: 13, color: Colors.white.withValues(alpha: .55),
          letterSpacing: 3,
        ),
      ),
    ],
  );

  Widget _bottomBar() => Container(
    height: 72,
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topCenter, end: Alignment.bottomCenter,
        colors: [Colors.transparent, Colors.black.withValues(alpha: .15)],
      ),
    ),
    padding: const EdgeInsets.symmetric(horizontal: 24),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(children: [
          Icon(Icons.wb_sunny_outlined,
              color: Colors.white.withValues(alpha: .65), size: 18),
          const SizedBox(width: 6),
          Text('맑음',
              style: TextStyle(
                  color: Colors.white.withValues(alpha: .65), fontSize: 13)),
        ]),
        Row(children: [
          Container(
            width: 90, height: 7,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: .22),
              borderRadius: BorderRadius.circular(4),
            ),
            child: FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: .7,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Icon(Icons.check, color: Colors.white.withValues(alpha: .75), size: 16),
        ]),
      ],
    ),
  );
}

// ════════════════════════════════════════════════════════════════
// B · CircleSplash — 영롱한 액체 그라데이션
// ════════════════════════════════════════════════════════════════

class CircleSplash extends StatefulWidget {
  const CircleSplash({super.key});

  @override
  State<CircleSplash> createState() => _CircleSplashState();
}

class _CircleSplashState extends State<CircleSplash>
    with TickerProviderStateMixin {
  late final AnimationController _ctrl;   // 액체 그라데이션
  late final AnimationController _fadeCtrl; // [버그수정2] 익명 → 명시 선언
  late final Animation<double> _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat(reverse: true);
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 3000),
    )..repeat(reverse: true);
    // [버그수정2] Gemini: 익명 AnimationController → dispose 불가 누수
    // Claude: _fadeCtrl 명시 → dispose()에서 정상 해제
    _fadeCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 800),
    )..forward();
    _fade = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
  }

  late final AnimationController _pulseCtrl;

  @override
  void dispose() {
    _ctrl.dispose();
    _fadeCtrl.dispose();  // ✅ 누수 수정
    _pulseCtrl.dispose(); // ✅
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();

    return Scaffold(
      backgroundColor: const Color(0xFF020208),
      body: Stack(children: [
        // 액체 그라데이션 레이어
        AnimatedBuilder(
          animation: _ctrl,
          builder: (_, __) {
            final t = _ctrl.value;
            return CustomPaint(
              size: MediaQuery.of(context).size,
              painter: _LiquidGradientPainter(t),
            );
          },
        ),
        // 유리 오버레이
        Positioned(
          left: 32, right: 32, top: 80, bottom: 80,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(40),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: .08),
                borderRadius: BorderRadius.circular(40),
                border: Border.all(
                    color: Colors.white.withValues(alpha: .18), width: 1),
              ),
            ),
          ),
        ),
        // 중앙 텍스트
        Center(
          child: _GlowPulse(
            color: Colors.white,
            child: _dateColumn(now),
          ),
        ),
      ]),
    );
  }

  Widget _dateColumn(DateTime now) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(
        now.day.toString().padLeft(2, '0'),
        style: const TextStyle(
          fontFamily: 'BebasNeue',
          fontSize: 160, color: Colors.white,
          height: .9, letterSpacing: -4,
        ),
      ),
      const SizedBox(height: 6),
      Text(
        _weekday(now),
        style: TextStyle(
          fontFamily: 'CourierPrime',
          fontSize: 20, fontWeight: FontWeight.w600,
          color: Colors.white.withValues(alpha: .9), letterSpacing: 4,
        ),
      ),
      const SizedBox(height: 4),
      Text(
        _weekStr(now),
        style: TextStyle(
          fontFamily: 'CourierPrime',
          fontSize: 13, color: Colors.white.withValues(alpha: .52),
          letterSpacing: 2,
        ),
      ),
    ],
  );
}

class _LiquidGradientPainter extends CustomPainter {
  final double t;
  _LiquidGradientPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    // 5개 색상 노드가 각기 다른 속도로 이동
    final nodes = [
      _node(size, .28 + .12 * math.sin(t * math.pi * 2),
          .28 + .1 * math.cos(t * math.pi * 2.3),
          const Color(0xFFFF0080), .85, size.width * .38),
      _node(size, .72 - .1 * math.cos(t * math.pi * 1.7),
          .62 + .12 * math.sin(t * math.pi * 1.5),
          const Color(0xFF00C8FF), .85, size.width * .45),
      _node(size, .42 + .08 * math.sin(t * math.pi * 2.8),
          .78 - .1 * math.cos(t * math.pi * 2.1),
          const Color(0xFF6400FF), .85, size.width * .38),
      _node(size, .78 - .09 * math.cos(t * math.pi * 1.9),
          .22 + .08 * math.sin(t * math.pi * 2.5),
          const Color(0xFFFFC800), .55, size.width * .30),
      _node(size, .55 + .06 * math.sin(t * math.pi * 3.1),
          .50 - .07 * math.cos(t * math.pi * 2.7),
          const Color(0xFF00FF96), .4, size.width * .28),
    ];

    for (final n in nodes) {
      canvas.drawCircle(n.$1, n.$2, Paint()..shader = n.$3);
    }
  }

  (Offset, double, Shader) _node(Size s, double fx, double fy,
      Color c, double opacity, double radius) {
    final center = Offset(s.width * fx, s.height * fy);
    return (
      center,
      radius,
      RadialGradient(
        colors: [c.withValues(alpha: opacity), Colors.transparent],
      ).createShader(Rect.fromCircle(center: center, radius: radius)),
    );
  }

  @override
  bool shouldRepaint(_LiquidGradientPainter old) => old.t != t;
}

// ════════════════════════════════════════════════════════════════
// C · ClassicSplash — 4개 링 독자 회전
// ════════════════════════════════════════════════════════════════

class ClassicSplash extends StatefulWidget {
  const ClassicSplash({super.key});

  @override
  State<ClassicSplash> createState() => _ClassicSplashState();
}

class _ClassicSplashState extends State<ClassicSplash>
    with TickerProviderStateMixin {
  // 링 4개: 각기 다른 속도·방향
  late final List<AnimationController> _ctrls;
  static const _specs = [
    (11000, false), // 링1: 11s 정방향
    (7000,  true),  // 링2: 7s 역방향
    (17000, false), // 링3: 17s 정방향
    (5000,  true),  // 링4: 5s 역방향
  ];

  @override
  void initState() {
    super.initState();
    _ctrls = _specs.map((s) => AnimationController(
      vsync: this,
      duration: Duration(milliseconds: s.$1),
    )..repeat()).toList();
  }

  @override
  void dispose() {
    for (final c in _ctrls) c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final size = MediaQuery.of(context).size;
    final cx = size.width / 2;
    final cy = size.height / 2;

    // 링 속성: [직경, 색상, stroke폭]
    const ringDefs = [
      (390.0, Color(0xFF03C75A), 2.5), // 그린
      (272.0, Color(0xFFFA233B), 2.5), // 레드
      (450.0, Color(0xFF2196F3), 2.0), // 블루
      (188.0, Color(0xFFFFB74D), 2.5), // 오렌지
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF0E0F1A),
      body: Stack(children: [
        // 링 4개
        ...List.generate(4, (i) {
          final (dia, color, stroke) = ringDefs[i];
          final reverse = _specs[i].$2;
          return AnimatedBuilder(
            animation: _ctrls[i],
            builder: (_, __) {
              final angle = (reverse ? -1 : 1) *
                  _ctrls[i].value * 2 * math.pi;
              return Positioned(
                left: cx - dia / 2,
                top: cy - dia / 2,
                child: Transform.rotate(
                  angle: angle,
                  child: CustomPaint(
                    size: Size(dia, dia),
                    painter: _ArcPainter(color, stroke),
                  ),
                ),
              );
            },
          );
        }),
        // 중앙 유리 카드
        Center(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: _noBlurOnWeb(),
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 52, vertical: 28),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: .55),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                      color: Colors.white.withValues(alpha: .08)),
                ),
                child: _dateColumn(now),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _dateColumn(DateTime now) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(
        now.day.toString().padLeft(2, '0'),
        style: const TextStyle(
          fontFamily: 'BebasNeue',
          fontSize: 120, color: Colors.white,
          height: .9, letterSpacing: -4,
          shadows: [Shadow(blurRadius: 16, color: Color(0x80000000))],
        ),
      ),
      const SizedBox(height: 4),
      Text(
        _weekday(now),
        style: TextStyle(
          fontFamily: 'CourierPrime',
          fontSize: 17, fontWeight: FontWeight.w600,
          color: Colors.white.withValues(alpha: .85), letterSpacing: 4,
        ),
      ),
      const SizedBox(height: 4),
      Text(
        _weekStr(now),
        style: TextStyle(
          fontFamily: 'CourierPrime',
          fontSize: 12, color: Colors.white.withValues(alpha: .42),
          letterSpacing: 2,
        ),
      ),
    ],
  );
}

class _ArcPainter extends CustomPainter {
  final Color color;
  final double strokeWidth;
  _ArcPainter(this.color, this.strokeWidth);

  @override
  void paint(Canvas canvas, Size size) {
    final r = size.width / 2;
    final center = Offset(r, r);
    // 희미한 전체 원
    canvas.drawCircle(
      center, r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withValues(alpha: .05),
    );
    // 색상 호
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: r),
      -math.pi / 2, // 12시 방향부터
      math.pi * .7, // 126도
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..strokeCap = StrokeCap.round
        ..color = color,
    );
  }

  @override
  bool shouldRepaint(_ArcPainter old) =>
      old.color != color || old.strokeWidth != strokeWidth;
}

// ════════════════════════════════════════════════════════════════
// D · AstronomicalSplash — 성운 + 글로우 링 + 별빛
// ════════════════════════════════════════════════════════════════

class AstronomicalSplash extends StatefulWidget {
  const AstronomicalSplash({super.key});

  @override
  State<AstronomicalSplash> createState() => _AstronomicalSplashState();
}

class _AstronomicalSplashState extends State<AstronomicalSplash>
    with TickerProviderStateMixin {
  late final List<AnimationController> _rings;
  late final AnimationController _nebCtrl;
  late final AnimationController _pulseCtrl;
  late final AnimationController _starCtrl; // [버그수정3] 별 45개→통합 1개
  final List<_StarData> _stars = List.generate(45, (_) {
    final rng = math.Random();
    return _StarData(
      x: rng.nextDouble(),
      y: rng.nextDouble(),
      size: rng.nextDouble() * 2.2 + 0.8,
      phaseOffset: rng.nextDouble(), // dur/delay 제거, phaseOffset으로 통일
    );
  });

  @override
  void initState() {
    super.initState();
    // 링 3개: 14s 정방향 / 9s 역방향 / 22s 정방향
    _rings = [
      AnimationController(vsync: this, duration: const Duration(seconds: 14))..repeat(),
      AnimationController(vsync: this, duration: const Duration(seconds: 9))..repeat(),
      AnimationController(vsync: this, duration: const Duration(seconds: 22))..repeat(),
    ];
    _nebCtrl = AnimationController(
      vsync: this, duration: const Duration(seconds: 14),
    )..repeat(reverse: true);
    _pulseCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 3500),
    )..repeat(reverse: true);
    // [버그수정3] 별 45개x개별 Controller -> 단일 통합
    _starCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
  }

  @override
  void dispose() {
    for (final c in _rings) c.dispose();
    _nebCtrl.dispose();
    _pulseCtrl.dispose();
    _starCtrl.dispose(); // ok 1개만 해제
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final size = MediaQuery.of(context).size;
    final cx = size.width / 2;
    final cy = size.height / 2;

    const ringDias = [340.0, 230.0, 410.0];
    const ringColors = [
      Color(0xFFFA233B),
      Color(0xFFFFB74D),
      Color(0xFF2196F3),
    ];
    const ringReverse = [false, true, false];

    return Scaffold(
      backgroundColor: const Color(0xFF050510),
      body: Stack(children: [
        // 성운 배경
        AnimatedBuilder(
          animation: _nebCtrl,
          builder: (_, __) => CustomPaint(
            size: size,
            painter: _NebulaPainter(_nebCtrl.value),
          ),
        ),
        // [버그수정3] 45개 Widget -> CustomPainter 1개
        AnimatedBuilder(
          animation: _starCtrl,
          builder: (_, __) => CustomPaint(
            size: size,
            painter: _StarsPainter(_stars, _starCtrl.value),
          ),
        ),
        // 글로우 링 3개
        ...List.generate(3, (i) {
          final dia = ringDias[i];
          final color = ringColors[i];
          final reverse = ringReverse[i];
          return AnimatedBuilder(
            animation: _rings[i],
            builder: (_, __) {
              final angle = (reverse ? -1 : 1) *
                  _rings[i].value * 2 * math.pi;
              return Positioned(
                left: cx - dia / 2,
                top: cy - dia / 2,
                child: Transform.rotate(
                  angle: angle,
                  child: CustomPaint(
                    size: Size(dia, dia),
                    painter: _GlowRingPainter(color),
                  ),
                ),
              );
            },
          );
        }),
        // 중앙 날짜
        Center(
          child: AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, child) {
              final glow = 0.3 + 0.7 * _pulseCtrl.value;
              return Stack(alignment: Alignment.center, children: [
                // 글로우 헤일로
                Container(
                  width: 160, height: 160,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFA233B).withValues(alpha: glow * .35),
                        blurRadius: 60 * glow,
                        spreadRadius: 10 * glow,
                      ),
                    ],
                  ),
                ),
                if (child != null) child,
              ]);
            },
            child: _dateColumn(now),
          ),
        ),
      ]),
    );
  }

  Widget _dateColumn(DateTime now) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(
        now.day.toString().padLeft(2, '0'),
        style: const TextStyle(
          fontFamily: 'BebasNeue',
          fontSize: 160, color: Colors.white,
          height: .9, letterSpacing: -4,
          shadows: [
            Shadow(blurRadius: 40, color: Color(0x99FA233B)),
            Shadow(blurRadius: 10, color: Color(0x44FA233B)),
          ],
        ),
      ),
      const SizedBox(height: 6),
      Text(
        _weekday(now),
        style: TextStyle(
          fontFamily: 'CourierPrime',
          fontSize: 20, fontWeight: FontWeight.w600,
          color: Colors.white.withValues(alpha: .85), letterSpacing: 4,
          shadows: [Shadow(blurRadius: 8,
              color: const Color(0xFFFA233B).withValues(alpha: .3))],
        ),
      ),
      const SizedBox(height: 4),
      Text(
        _weekStr(now),
        style: TextStyle(
          fontFamily: 'CourierPrime',
          fontSize: 13,
          color: const Color(0xFFFFB74D).withValues(alpha: .65),
          letterSpacing: 2,
        ),
      ),
    ],
  );
}

class _NebulaPainter extends CustomPainter {
  final double t;
  _NebulaPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    void ellipse(double fx, double fy, double rx, double ry, Color c) {
      final center = Offset(size.width * fx, size.height * fy);
      final rect = Rect.fromCenter(center: center, width: rx * 2, height: ry * 2);
      canvas.drawOval(
        rect,
        Paint()..shader = RadialGradient(
          colors: [c, Colors.transparent],
        ).createShader(rect),
      );
    }

    final scale = 1.0 + 0.06 * math.sin(t * math.pi);
    canvas.save();
    canvas.translate(size.width / 2, size.height / 2);
    canvas.scale(scale);
    canvas.translate(-size.width / 2, -size.height / 2);

    ellipse(.30, .25, size.width * .55, size.height * .5,
        const Color(0xFFFA233B).withValues(alpha: .13));
    ellipse(.70, .70, size.width * .55, size.height * .5,
        const Color(0xFF2196F3).withValues(alpha: .10));
    ellipse(.50, .50, size.width * .5,  size.height * .5,
        const Color(0xFFFFB74D).withValues(alpha: .07));

    canvas.restore();
  }

  @override
  bool shouldRepaint(_NebulaPainter old) => old.t != t;
}

class _GlowRingPainter extends CustomPainter {
  final Color color;
  _GlowRingPainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final r = size.width / 2;
    final center = Offset(r, r);
    // 글로우 (두꺼운 흐린 선)
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: r),
      -math.pi / 2, math.pi * .8, false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 8
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6)
        ..color = color.withValues(alpha: .4),
    );
    // 선명한 호
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: r),
      -math.pi / 2, math.pi * .8, false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..strokeCap = StrokeCap.round
        ..color = color.withValues(alpha: .55),
    );
  }

  @override
  bool shouldRepaint(_GlowRingPainter old) => old.color != color;
}

class _StarData {
  final double x, y, size, phaseOffset;
  _StarData({
    required this.x, required this.y,
    required this.size, required this.phaseOffset,
  });
}



// ════════════════════════════════════════════════════════════════
// 공통 유틸
// ════════════════════════════════════════════════════════════════

/// 글로우 펄스 애니메이션 래퍼 (B 테마 날짜 숫자용)
class _GlowPulse extends StatefulWidget {
  final Widget child;
  final Color color;
  const _GlowPulse({required this.child, required this.color});

  @override
  State<_GlowPulse> createState() => _GlowPulseState();
}

class _GlowPulseState extends State<_GlowPulse>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 3000),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _ctrl,
    builder: (_, child) {
      final v = _ctrl.value;
      return Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: widget.color.withValues(alpha: .15 + .25 * v),
              blurRadius: 40 + 40 * v,
              spreadRadius: 0,
            ),
          ],
        ),
        child: child,
      );
    },
    child: widget.child,
  );
}

ui.ImageFilter _noBlurOnWeb() =>
    ui.ImageFilter.blur(sigmaX: 8, sigmaY: 8);
